package com.example.wifiendi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button enableButton, disButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enableButton = findViewById(R.id.button1);
        disButton = findViewById(R.id.button2);

        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the device is running Android 10 (API 29) or higher
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Direct the user to the Wi-Fi settings page instead of enabling Wi-Fi programmatically
                    Intent intent = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS);
                    startActivity(intent);
                } else {
                    // For older versions, Wi-Fi can still be enabled programmatically
                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    wifiManager.setWifiEnabled(true);
                }
            }
        });

        disButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the device is running Android 10 (API 29) or higher
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Direct the user to the Wi-Fi settings page instead of disabling Wi-Fi programmatically
                    Intent intent = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS);
                    startActivity(intent);
                } else {
                    // For older versions, Wi-Fi can still be disabled programmatically
                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    wifiManager.setWifiEnabled(false);
                }
            }
        });
    }
}
